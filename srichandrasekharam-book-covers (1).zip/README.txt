Srichandrasekharam storefront book covers

Upload the five files in the covers/ folder to the connected GitHub repository:
kartyji/srichandrasekharam-storefront1

Keep the original book PDFs private. These are cover images only.
